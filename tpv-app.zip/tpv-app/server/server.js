const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "../public"))); // servir archivos estáticos

// Inicializar base de datos
const db = new sqlite3.Database(path.join(__dirname, "../db/tpv.sqlite"), (err) => {
  if (err) console.error("Error abriendo base de datos:", err);
  else console.log("Base de datos SQLite conectada");
});

// Crear tablas si no existen
const crearTablas = () => {
  db.run(`CREATE TABLE IF NOT EXISTS productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    precio REAL NOT NULL,
    categoria TEXT NOT NULL,
    imagen TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS pedidos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mesa TEXT NOT NULL,
    productos TEXT NOT NULL,
    total REAL NOT NULL,
    fecha TEXT NOT NULL
  )`);
};

crearTablas();

// Rutas API

// Obtener productos
app.get("/api/productos", (req, res) => {
  db.all("SELECT * FROM productos", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Añadir nuevo producto
app.post("/api/productos", (req, res) => {
  const { nombre, precio, categoria, imagen } = req.body;
  db.run(
    `INSERT INTO productos (nombre, precio, categoria, imagen) VALUES (?, ?, ?, ?)`,
    [nombre, precio, categoria, imagen],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

// Guardar pedido
app.post("/api/pedidos", (req, res) => {
  const { mesa, productos, total, fecha } = req.body;
  db.run(
    `INSERT INTO pedidos (mesa, productos, total, fecha) VALUES (?, ?, ?, ?)`,
    [mesa, JSON.stringify(productos), total, fecha],
    function (err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

// Obtener todos los pedidos
app.get("/api/pedidos", (req, res) => {
  db.all("SELECT * FROM pedidos ORDER BY fecha DESC", [], (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

// Servidor listo
app.listen(PORT, () => {
  console.log(`Servidor TPV corriendo en http://localhost:${PORT}`);
});
